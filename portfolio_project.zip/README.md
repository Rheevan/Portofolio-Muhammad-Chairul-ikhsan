# Portfolio - Chairul Iksan

Proyek portofolio sederhana (3 halaman) untuk mata kuliah Pemrograman Lanjut.

## Isi project
- `index.html` — Halaman utama (Home)
- `about.html` — Halaman tentang (About)
- `portfolio.html` — Halaman portofolio (Portfolio)
- `styles.css` — Stylesheet sederhana

## Cara submit (buat repo GitHub dan dapatkan link)
1. Buat folder kerja dan ekstrak isi zip ini.
2. Inisialisasi git, commit, dan push:
```bash
cd portfolio_project
git init
git add .
git commit -m "Initial commit: portfolio project"
# buat repo baru di GitHub (contoh: portfolio-chairul-iksan), lalu:
git remote add origin https://github.com/YOUR_USERNAME/portfolio-chairul-iksan.git
git branch -M main
git push -u origin main
```
3. Setelah push, buka halaman repo GitHub dan salin link (contoh: `https://github.com/YOUR_USERNAME/portfolio-chairul-iksan`).
4. Untuk men-deploy (opsional) gunakan GitHub Pages:
   - Settings → Pages → pilih branch `main` dan folder `/ (root)` → Save.
   - Setelah aktif, link GitHub Pages biasanya `https://YOUR_USERNAME.github.io/portfolio-chairul-iksan/`

## Catatan untuk dosen / penilai
- Situs ini responsif sederhana dan mudah dimodifikasi.
- Jika Anda ingin, saya bisa bantu:
  - Menambahkan halaman kontak dengan form (menggunakan form backend atau static form + formspree).
  - Mengubah desain atau menambahkan projek nyata dengan link live.
